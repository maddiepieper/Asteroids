import java.util.ArrayList;
import java.util.List;
/**
 * This class controls the game by initializing the list of asteroids and bullets, instantiates the ship, 
 * and keeps track of score and ships remaining
 */
public class Game {

	private Ship ship;
	private List<Asteroid> asteroids;
	private List<Bullet> bullets;
	private int shipCounter;
	private int points;

	
	public Game(int left, int right, int top, int bottom) {
		ship = new Ship(left, right, top, bottom);
		points = 0;
		shipCounter = 3;
		asteroids = new ArrayList<>();
		bullets = new ArrayList<>();
		
		//creating list of asteroids
		double centerx = (left+right)/2;
		double centery = (top+bottom)/2;
		final int MAX = 10; //max number of asteroids
		
		//this loop creates the asteroids, then ensures theyre not right next to the ship
		for (int i=0; i<MAX; i++) {
			double x = Math.random() * (right - left) + left; //starting location of asteroids
			double y = Math.random() * (bottom - top) + top;
			int size = (int) (20+Math.random()*10); //size of asteroid between 20 and 30
			double dx = Math.random()*5;
			double dy = Math.random()*5;
			double deltaAngle = Math.random()*90;
			
			
			// if asteroid is not within 50 pixels of middle of game space, it is added to list of asteroids
			if (!((x>centerx-50 && x<centerx+50) || (y>centery-50 && y<centery+50))) {
				Asteroid asteriod = new Asteroid(left, right, top, bottom, size);
				asteriod.setLocation((int) x, (int) y);
				asteriod.setVelocity(dx, dy);
				asteriod.setDeltaAngle(deltaAngle);
				asteroids.add(asteriod);
			}
		}
	}
	
	
	/*
	 * Updates the locations of everything, removes collided objects, updates score and ship counter.
	 */
	public void updateAll() {
		ship.update();
		List<Asteroid> newAsteroids = new ArrayList<>(); //new list without asteroids that collided with ship.
		for (Asteroid asteroid:asteroids) {
			asteroid.move();
			if (ship.isCollided(asteroid)) {
				shipCounter--;
			} else {
				newAsteroids.add(asteroid);
			}
		}
		asteroids = newAsteroids; //assigns new list to original handle
		
		
		//removes bullets and asteroids that have collided, removes old bullets
		List<Asteroid> asteroidsToRemove = new ArrayList<>(); 
		List<Bullet> bulletsToRemove = new ArrayList<>(); 
		
		for (Bullet bullet:bullets) {
			bullet.move();
			if (bullet.isTooOld()) {
				bulletsToRemove.add(bullet);
			}
			for (Asteroid asteroid:asteroids) {
				if (bullet.isCollided(asteroid)) {
					points = points+20; //adds 20 points for hitting an asteroid
					bulletsToRemove.add(bullet);
					asteroidsToRemove.add(asteroid);
				}
			}
		}
		List<Bullet> newBullets = new ArrayList<>();
		for (Bullet bullet:bullets) {
			if (!(bulletsToRemove.contains(bullet))) {
				newBullets.add(bullet);
			}
		}
		bullets = newBullets; //assigns new list to original handle
		
		newAsteroids = new ArrayList<>(); 
		for (Asteroid asteroid:asteroids) {
			if (!(asteroidsToRemove.contains(asteroid))) {
				newAsteroids.add(asteroid);
			}
		}
		asteroids = newAsteroids; //assigns new list to original handle	

	}
	
	
	
	
	
	public boolean isGameOver() {
		return (shipCounter==0 || asteroids.isEmpty());
	}
	
	/*
	 * Player wins if there are no asteroids remaining
	 */
	public boolean playerWins() {
		return (this.isGameOver() && asteroids.isEmpty());
	}
	
	public void shoot() {
		Bullet bullet = ship.shoot();
		bullets.add(bullet);
	}
	
	public void turnCW() {
		ship.rotate(10); //degrees
	}
	
	public void turnCCW() {
		ship.rotate(-10);

	}
	
	/*
	 * Takes the old velocity, and adds the ships current orientation angle to get the new velocity.
	 * Uses cos and sin to get the x and y components from the angle and add them to dx and dy respectively
	 */
	public void thrust() {
		final int THRUST = 1; //factor ship accelerates by
		ship.setVelocity(ship.getDx()+THRUST*Math.cos(Math.toRadians(ship.getAngle())), ship.getDy()+THRUST*Math.sin(Math.toRadians(ship.getAngle())));
	}

	public Ship getShip() {
		return ship;
	}

	public List<Asteroid> getAsteroids() {
		return asteroids;
	}

	public List<Bullet> getBullets() {
		return bullets;
	}
	
	public int getShipCounter() {
		return shipCounter;
	}
	
	public int getScore() {
		return points;
	}
	
	

	
		

}
