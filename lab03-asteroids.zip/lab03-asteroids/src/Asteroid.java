import java.awt.Color;
import java.awt.Polygon;

/**
 * This class inherits polygon sprite and creates asteroids
 */
public class Asteroid extends PolygonSprite {

	private double deltaAngle;
	
	public Asteroid(int left, int right, int top, int bottom, int size) {
		super(left, right, top, bottom);
		setSize(size); //sets radius of the asteroid
		int n = (int) (5+Math.random()*5); //number of sides (between 5 and 10)
		
		//creating the asteroid polygon
		Polygon poly = new Polygon();
		double angle = super.getAngle();
		setMyColor(Color.DARK_GRAY);

		//adding the points
		for (int i=0; i<n; i++) {
			double randSize = size+Math.random()*10;
			int x = (int) Math.round(randSize*Math.cos(Math.toRadians(angle)));
			int y = (int) Math.round(randSize*Math.sin(Math.toRadians(angle)));;
			poly.addPoint(x, y);
			angle = angle + (360/n);
		}
		
		setMyPolygon(poly);
	}
	
	/*
	 * Wraps around asteroids if they go past the edge of the frame
	 */
	@Override
	public void move() {
		super.move();
		if (this.getX()>maxx) {
			this.setX(minx);
		} else if (this.getY()>maxy ) {
			this.setY(miny);
		}
		if (this.getX()<minx) {
			this.setX(maxx);
		} else if (this.getY()<miny) {
			this.setY(maxy);
		}
		super.setAngle(super.getAngle()+deltaAngle);
	}
	
	public void update() {
		
	}

	public double getDeltaAngle() {
		return deltaAngle;
	}

	public void setDeltaAngle(double deltaAngle) {
		this.deltaAngle = deltaAngle;
	}

}
