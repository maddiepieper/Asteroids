import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JPanel;

/**
 * This class sets a panel which displays the score and number of ships remaining
 */
public class DashPanel extends JPanel{
	
	private Game theGame;

	/*
	 * Sets size and color of the panel
	 */
	public DashPanel(Game Game) {
		this.theGame = Game;
		this.setBackground(Color.DARK_GRAY);
		final int SIZE = 40; //height of the dash panel
		this.setMinimumSize(new Dimension(0, SIZE));
		this.setMaximumSize(new Dimension(1000, SIZE));
		this.setPreferredSize(new Dimension(1000, SIZE));
	}
	
	/*
	 * Draws the strings inside the dash panel
	 */
	public void paintComponent(Graphics gfx) {
		super.paintComponent(gfx);
		gfx.setColor(Color.WHITE);
		final int YLOCATION = 20; //how far the text is from the top of the frame
		gfx.drawString("Ships Remaining: "+theGame.getShipCounter(), 20, YLOCATION);
		gfx.drawString("Score: "+theGame.getScore(), 400, YLOCATION);
	}

}
