import java.awt.Graphics;

/**
 * This class outlines a bullet and its movement
 */
public class Bullet extends Sprite {

	private int age; //this variable decreases as bullet moves, and is removed when negative
	
	public Bullet (int left, int right, int top, int bottom) {
		super(left, right, top, bottom);
		final int START_AGE = 50;
		age = START_AGE;
	}
	
	
	@Override
	public void move() {
		super.move();
		age--;
	}
	/*
	 * draws line from current location of ship and "shoots" in the direction of its velocity, which is set in the ship class.
	 */
	public void drawOn(Graphics g) {
		g.drawLine((int) this.getX(), (int) this.getY(), (int) (this.getX()+this.getDx()), (int) (this.getY()+this.getDy()));
	}
	
	public void update() {
		
	}
	
	public boolean isTooOld() {
		return (age<0);
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
