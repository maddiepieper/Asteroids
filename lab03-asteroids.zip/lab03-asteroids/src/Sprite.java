import java.awt.Graphics;

/**
 * A sprite	manages	his	own	location of	the	
Sprite’s center	point (x,y), animation mobility boundaries (minx, maxx, miny, maxy) and	
velocity (dx, dy). In	addition, the sprite keeps track of	its	size (the radius of	a bounding
circle/bubble).		
 */
public abstract class Sprite {
	
	private double x, y;
	private double dx, dy;
	private double size;
	public double minx, maxx, miny, maxy;
	
	/*
	 * Initializes the sprite's boundaries, sets x and y to mid point of them, and sets velocity to 0.
	 */
	public Sprite(int left, int right, int top, int bottom) {
		minx = left;
		maxx = right;
		miny = top;
		maxy = bottom;
		x = (minx+maxx)/2;
		y = (miny+maxy)/2;
		dx = 0;
		dy = 0;
	}
	
	/*
	 * Returns true if two sprites collide (if their radii "overlap")
	 */
	public boolean isCollided(Sprite other) {
		double otherX = other.getX();
		double otherY = other.getY();
		double changeinx = otherX-x;
		double changeiny = otherY-y;
		double distance = Math.sqrt(Math.pow(changeinx, 2)+Math.pow(changeiny, 2));
		return (distance<(this.size + other.getSize()));
	}
	
	public void setLocation(int nx, int ny) {
		x = nx;
		y = ny;
	}
	
	public void setVelocity(double dx, double dy) {
		this.dx = dx;
		this.dy = dy;
	}
	
	public void setSize(int nsize) {
		size = nsize;
	}
	
	public abstract void drawOn(Graphics g);
	
	public void move() {
		x = x+dx;
		y = y+dy;
	}
	
	public abstract void update();
	
	public boolean isOutOfBounds() {
		return (x < minx || x > maxx || y < miny || y > maxy);
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getDx() {
		return dx;
	}

	public void setDx(double dx) {
		this.dx = dx;
	}

	public double getDy() {
		return dy;
	}

	public void setDy(double dy) {
		this.dy = dy;
	}

	public double getSize() {
		return size;
	}
	
	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}



}
