import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.AffineTransform;

/**
 * This class describes a Sprite in the shape of a polygon, and keeps track of its orientation (angle).
 */
public abstract class PolygonSprite extends Sprite {
	
	private Polygon myPolygon;
	private Color myColor;
	private double angle;
	
	public PolygonSprite(int left, int right, int top, int bottom) {
		super(left, right, top, bottom);
		angle = 0;
	}
	
	/*
	 * Uses affine transforms to move the polygons (asteroids and ship)
	 */
	public void drawOn(Graphics gfx) {
		Graphics2D g = (Graphics2D) gfx; 
		g.setColor(myColor);
		AffineTransform xf = g.getTransform(); 
		g.translate(super.getX(), super.getY()); 
		g.rotate(Math.toRadians(angle)); 
		g.fillPolygon(this.myPolygon);
		g.setTransform(xf);
	}
	
	/*
	 * Rotates the polygon
	 */
	public void rotate(double theta) {
		angle+=theta;
	}

	public Polygon getMyPolygon() {
		return myPolygon;
	}

	public void setMyPolygon(Polygon myPolygon) {
		this.myPolygon = myPolygon;
	}

	public Color getMyColor() {
		return myColor;
	}

	public void setMyColor(Color myColor) {
		this.myColor = myColor;
	}

	public double getAngle() {
		return angle;
	}

	public void setAngle(double angle) {
		this.angle = angle;
	}
	
	

}
