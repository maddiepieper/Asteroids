import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;

/**
 * This class controls the game by reacting to a timer and keys pressed
 */
public class GameController extends Object implements KeyListener, ActionListener {
	
	private Timer timer;
	private Game theGame;
	private MainFrame main;
	private DashPanel dash;

	
	public GameController(MainFrame main, Game theGame, DashPanel dash) {
		this.dash = dash;
		this.theGame = theGame;
		this.main = main;
		timer = new Timer(1000/15, this);
		timer.start();
	}
	
	/*
	 * Updates the game and repaints the panels every "tick" of the timer
	 */
	public void onTimerAction() {
		theGame.updateAll();
		if (theGame.isGameOver()) {
			timer.stop();
		}
		dash.repaint();
		main.repaint();
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		onTimerAction();
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		
	}

	/*
	 * Tells the game what to do when certain keys are pressed
	 */
	@Override
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode())
        {
           case KeyEvent.VK_UP:
        	  theGame.thrust();
              break;
           case KeyEvent.VK_LEFT:
        	  theGame.turnCCW();
              break;
           case KeyEvent.VK_RIGHT:
        	  theGame.turnCW();
              break;
           case KeyEvent.VK_SPACE:
        	   theGame.shoot();
        	   break;
        }
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
	}

}
