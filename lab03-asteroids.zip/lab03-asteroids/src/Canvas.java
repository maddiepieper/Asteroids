import java.awt.Graphics;
import javax.swing.JPanel;

/**
 * This class is the "canvas" on which the game is displayed.
 */
public class Canvas extends JPanel{
	
	private Game theGame;

	public Canvas(Game theGame) {
		this.theGame = theGame;
		this.setFocusable(true);
	    this.requestFocus();
		
	}
	
	/*
	 * If the game is over, it displays the end screen. 
	 * Otherwise, it updates the asteroid, bullets, and ships locations
	 */
	public void paintComponent(Graphics gfx) {
		
		if (theGame.isGameOver()) {
			String win;
			if (theGame.playerWins()) {
				win = "You Won!";
			} else {
				win = "You Lost :(";
			}
			gfx.drawString("Game Over. "+win, ((MainFrame.MAXX+MainFrame.MINX)/2), ((MainFrame.MINY+MainFrame.MAXY)/2));
			gfx.drawString("Final Score: "+theGame.getScore(), (((MainFrame.MAXX+MainFrame.MINX)/2)), ((MainFrame.MINY+MainFrame.MAXY)/2)+30);

		} else {
			theGame.updateAll();
			for (Asteroid asteroid : theGame.getAsteroids()) {
	            asteroid.drawOn(gfx);  // Call drawOn for each asteroid
			}
			for (Bullet bullet: theGame.getBullets()) {
				bullet.drawOn(gfx);
			}
			theGame.getShip().drawOn(gfx);
		}
	}
}