import java.util.Timer;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Graphics;

/**
 * This class sets the size of the frame, instantiates the game, game controller, and adds the canvas and dash panels to the frame.
 */
public class MainFrame extends JFrame {
	
	private Game theGame;
	private GameController controller;
	private DashPanel dash;
	private Canvas theCanvas;
	private Timer timer;
	public static final int MAXX = 800;
	public static final int MINX = 0;
	public static final int MAXY = 800;
	public static final int MINY = 0;

	public MainFrame() {
		theGame = new Game(MINX, MAXX, MINY, MAXY);
		dash = new DashPanel(theGame);
		controller = new GameController(this, theGame, dash);
		theCanvas = new Canvas(theGame);
		
		this.setSize(MAXX,MAXY); 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.add(theCanvas, BorderLayout.CENTER);
		this.add(dash, BorderLayout.SOUTH);
		theCanvas.addKeyListener(controller);
			
	}
	

	public static void main(String[] args) {
		MainFrame main = new MainFrame();
		main.setVisible(true);
		
	}

}
