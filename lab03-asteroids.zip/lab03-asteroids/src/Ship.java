import java.awt.Color;
import java.awt.Polygon;

/**
 * This class describes the main ship and its methods
 */
public class Ship extends PolygonSprite{

	private int left, right, top, bottom;
	
	/*
	 * Creates the ship
	 */
	public Ship(int left, int right, int top, int bottom) {
		super(left, right, top, bottom);
		this.left = left;
		this.right = right;
		this.top = top;
		this.bottom = bottom;
		
		//create ship shaped polygon
		Polygon poly = new Polygon();
		poly.addPoint(15, 0);
		poly.addPoint(-5, -8);
		poly.addPoint(-5, 8);
		
		super.setMyColor(Color.RED);
		setMyPolygon(poly);
	}
	
	/*
	 * Creates a new bullet, sets its starting location to the ships', and sets its velocity as a multiple of the ships' orientation
	 */
	public Bullet shoot() {
		Bullet bullet = new Bullet(left, right, top, bottom);
		bullet.setLocation((int) this.getX(), (int) this.getY());
		final int SCALE = 10;
		bullet.setVelocity(this.getDx()+SCALE*Math.cos(Math.toRadians(this.getAngle())), this.getDy()+SCALE*Math.sin(Math.toRadians(this.getAngle())));
		return bullet;
	}

	/*
	 * Moves ship, and wraps it around if out of bounds
	 */
	@Override
	public void update() {
		super.move();
		if (this.getX()>maxx) {
			this.setX(minx);
		} else if (this.getY()>maxy ) {
			this.setY(miny);
		}
		if (this.getX()<minx) {
			this.setX(maxx);
		} else if (this.getY()<miny) {
			this.setY(maxy);
		}

	}
	
	

	
}
